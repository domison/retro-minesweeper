export const MAX_ROWS = 9;
export const MAX_COLS = 9;
export const NO_OF_BOMBS = 10;
